pred_dir   = 'dis646on1ktest/';
gt_dir     = 'alpha_copy/';
trimap_dir = 'trimaps/';

step = 0.1;  % for connectivity error

pred_files = dir(fullfile(pred_dir, '*.png'));  % adjust extension if needed

grad_losses = [];
conn_losses = [];
mse_losses  = [];
sad_losses  = [];
names       = {};

for i = 1:length(pred_files)

    name = pred_files(i).name;

    pred_path   = fullfile(pred_dir, name);
    gt_path     = fullfile(gt_dir, name);
    trimap_path = fullfile(trimap_dir, name);

    if ~isfile(gt_path) || ~isfile(trimap_path)
        fprintf('[%d/%d] "%s" skipping\n', i, length(pred_files), name);
        continue;
    end

    % Load images
    pred   = imread(pred_path);
    target = imread(gt_path);
    trimap = imread(trimap_path);

    if ndims(pred) == 3,   pred   = rgb2gray(pred);   end
    if ndims(target) == 3, target = rgb2gray(target); end
    if ndims(trimap) == 3, trimap = rgb2gray(trimap); end

    % Count unknown pixels
    unknown = sum(trimap(:) == 128);
    if unknown == 0
        fprintf('[%d/%d] "%s" has no unknown region, skipping\n', ...
                i, length(pred_files), name);
        continue;
    end

    % ---- Raw metric computation ----
    grad_raw = compute_gradient_loss(pred, target, trimap);
    conn_raw = compute_connectivity_error(pred, target, trimap, step);
    mse_loss = compute_mse_loss(pred, target, trimap);
    sad_loss = compute_sad_loss(pred, target, trimap);

    % ---- Normalize per pixel ----
    grad_norm = grad_raw / unknown;
    conn_norm = conn_raw / unknown;

    % ---- Paper-scale reporting (IMPORTANT) ----
    grad_loss = grad_norm * 1000;
    conn_loss = conn_norm * 1000;

    % Store
    grad_losses(end+1) = grad_loss;
    conn_losses(end+1) = conn_loss;
    mse_losses(end+1)  = mse_loss;
    sad_losses(end+1)  = sad_loss;

    fprintf('[%d/%d] "%s"\n', i, length(pred_files), name);
    fprintf('  Grad: %.2f | Conn: %.2f | MSE: %.4f | SAD: %.2f\n', ...
            grad_loss, conn_loss, mse_loss, sad_loss);
end
grad_lossf=mean(grad_losses);
conn_lossf=mean(conn_losses);
mse_lossf=mean(mse_losses);
sad_lossf=mean(sad_losses);
fprintf('avg: Grad: %.2f | Conn: %.2f | MSE: %.4f | SAD: %.2f\n', ...
            grad_lossf, conn_lossf, mse_lossf, sad_lossf);